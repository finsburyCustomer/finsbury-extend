package com.acmecorp.xtendm3extensions

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class XtendM3ExtensionsApplication {

  static void main(String[] args) {
    SpringApplication.run(XtendM3ExtensionsApplication, args)
  }
}
